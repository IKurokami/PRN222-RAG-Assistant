# Member 4 - Flow 2 RAG Backend Implementation Plan

## Executive Summary

This plan completes the **Flow 2 RAG Question & Answer backend** for Member 4. The implementation must be **provider-neutral**, **subject-scoped**, and follow the established architecture boundaries.

**Current State**: Core interfaces and partial implementations exist but have critical gaps:
- ❌ No subject-scoped retrieval (PgVector retriever filters only by IndexStatus)
- ❌ ChatSession lacks SubjectId (persistence limitation noted in AGENTS.md)
- ❌ Conversation history not fully integrated
- ❌ Missing resilience patterns (retry, proper cancellation)
- ❌ Incomplete test coverage (integration tests skipped)

---

## Phase 1: Schema & Persistence Fixes (Coordinate with Member 1)

### 1.1 Add SubjectId to ChatSession (Migration Required)

**Rationale**: Per `Application/AGENTS.md`: "Current Flow 2 persistence limitation: ChatSession has no SubjectId. Coordinate any needed persistence change with Member 1."

**Files to modify**:
- `src/PRN222.RagAssistant/Domain/Entities/ChatSession.cs` — add `SubjectId`
- `src/PRN222.RagAssistant/Data/Configurations/ChatSessionConfiguration.cs` — add FK + index
- `src/PRN222.RagAssistant/Data/Migrations/20260811082331_*.cs` — **new migration** (do NOT modify existing)

**New Migration**: `AddSubjectIdToChatSession`
```csharp
// Up()
migrationBuilder.AddColumn<Guid>(
    name: "SubjectId",
    table: "ChatSessions",
    type: "uuid",
    nullable: false,
    defaultValue: new Guid("d50db4a1-a8b1-4f49-9c43-89d78be62511")); // PRN222 default

migrationBuilder.CreateIndex(
    name: "IX_ChatSessions_SubjectId",
    table: "ChatSessions",
    column: "SubjectId");

migrationBuilder.AddForeignKey(
    name: "FK_ChatSessions_Subjects_SubjectId",
    table: "ChatSessions",
    column: "SubjectId",
    principalTable: "Subjects",
    principalColumn: "Id",
    onDelete: ReferentialAction.Restrict);
```

### 1.2 Update RagQueryService to use SubjectId

- Validate session belongs to user AND subject context
- Pass SubjectId to retriever for scoped search

---

## Phase 2: Subject-Scoped Retrieval (Critical Fix)

### 2.1 Fix PgVectorDocumentChunkRetriever

**Current issue**: SQL query only filters by `d."IndexStatus" = 'Indexed'`, missing SubjectId filter.

**Required change**: Add `SubjectId` parameter to `SearchAsync` and filter by it.

```csharp
// Interface change (InternalTypes.cs)
public interface IDocumentChunkRetriever
{
    Task<IReadOnlyList<RetrievedChunk>> SearchAsync(
        float[] questionEmbedding,
        Guid subjectId,                    // NEW: required for multi-subject
        CancellationToken cancellationToken = default);
}

// Implementation change (PgVectorDocumentChunkRetriever.cs)
var sql = $@"
    SELECT ...
    FROM ""DocumentChunks"" dc
    JOIN ""Documents"" d ON d.""Id"" = dc.""DocumentId""
    WHERE d.""SubjectId"" = @subjectId      -- NEW
      AND d.""IndexStatus"" = 'Indexed'
      AND dc.""Embedding"" IS NOT NULL
    ORDER BY dc.""Embedding"" <=> @embedding
    LIMIT {topK}";
```

### 2.2 Update RagQueryService.AskAsync

```csharp
// Get subjectId from session
var subjectId = session.SubjectId;

// Pass to retriever
var allChunks = await _retriever.SearchAsync(questionEmbedding, subjectId, cancellationToken);
```

---

## Phase 3: Conversation History Integration

### 3.1 Complete IncludeConversationHistory Feature

**Current state**: Option exists in `RagOptions.Retrieval.IncludeConversationHistory` but `LoadRecentHistoryAsync` loads ALL messages without subject context.

**Required changes**:
- Ensure history only from same session (already done)
- Respect `HistoryTurns` config
- Format history properly for prompt injection

### 3.2 Update GroundedPromptBuilder

- Include history block when `IncludeConversationHistory = true`
- Use `RagOptions.Retrieval.HistoryTurns` for limit
- Clear delimiter between history and current question

---

## Phase 4: Resilience & Error Handling

### 4.1 Embedding Retry Logic

Add retry with exponential backoff for `ITextEmbeddingService.EmbedAsync`:
- Max 2 retries
- Exponential backoff: 500ms, 1s
- Only for transient failures (timeout, 5xx)

### 4.2 Proper Cancellation Handling

- Respect `CancellationToken` in all async operations
- If cancelled during chat generation: persist user message, skip assistant message
- Log cancellation clearly (not as error)

### 4.3 Structured Logging

Add structured logging with:
- `SessionId`, `UserId`, `SubjectId`
- `LatencyMs` (embedding, retrieval, chat)
- `TopK`, `ReturnedCitations`
- `EmbeddingModel`, `ChatModel` (from DI)

---

## Phase 5: Vector Index for Performance (Coordinate with Member 1)

### 5.1 Add HNSW Index on DocumentChunks.Embedding

**New Migration**: `AddHnswIndexOnDocumentChunksEmbedding`
```csharp
// Up()
migrationBuilder.Sql(@"
    CREATE INDEX IF NOT EXISTS ""IX_DocumentChunks_Embedding_Hnsw""
    ON ""DocumentChunks"" USING hnsw (""Embedding"" vector_cosine_ops)
    WITH (m = 16, ef_construction = 64);
");
```

**Note**: HNSW chosen over IVFFlat because it doesn't require training data and works well for demo-scale datasets.

---

## Phase 6: Complete Test Coverage

### 6.1 Unit Tests (InMemory EF Core)

Create comprehensive tests in `tests/PRN222.RagAssistant.Tests/RagQueryServiceTests.cs`:

| Test | Description |
|------|-------------|
| `AskAsync_ValidatesSessionOwnership` | Rejects session belonging to different user |
| `AskAsync_ValidatesSubjectScope` | Rejects session from different subject |
| `AskAsync_ReturnsNoEvidence_WhenNoChunksFound` | Returns configured no-evidence message |
| `AskAsync_PersistsUserAndAssistantMessages` | Both messages saved with correct roles |
| `AskAsync_PersistsCitationsWithCorrectRank` | Citations have Rank 1..N |
| `AskAsync_TruncatesExcerptToConfiguredLength` | Uses `ExcerptChars` from options |
| `AskAsync_RespectsCancellationToken` | Cancels during embedding/chat |
| `AskAsync_RollsBackAssistantOnChatFailure` | No orphan assistant message if chat fails |
| `AskAsync_IncludesHistoryWhenEnabled` | History injected into prompt |
| `AskAsync_ExcludesHistoryWhenDisabled` | No history when `IncludeConversationHistory = false` |

### 6.2 Architecture/Convention Tests

Add `tests/PRN222.RagAssistant.Tests/RagArchitectureTests.cs`:

```csharp
[Fact]
public void RagQueryService_DoesNotReferencePgvectorDirectly()
{
    // Verify no "using Pgvector;" in Features/Rag
}

[Fact]
public void RagQueryService_OnlyDependsOnApplicationAndInternalAbstractions()
{
    // Verify no direct Npgsql, HttpClient usage
}

[Fact]
public void AllConfigurationViaIOptions_RagOptions()
{
    // No magic numbers, all via IOptions<RagOptions>
}
```

### 6.3 Retriever Tests

`tests/PRN222.RagAssistant.Tests/PgVectorDocumentChunkRetrieverTests.cs`:
- Test subject-scoped SQL generation
- Test empty results handling
- Test similarity score calculation

---

## Phase 7: Configuration & Documentation

### 7.1 Verify All Config Options Work

Ensure these `RagOptions` are actually used:
- `Retrieval.TopK` ✓ (used)
- `Retrieval.MinimumSimilarityScore` ✓ (used)
- `Retrieval.MaxContextChars` ✓ (used in GroundedPromptBuilder)
- `Retrieval.IncludeConversationHistory` → **implement**
- `Retrieval.HistoryTurns` → **implement**
- `Retrieval.ExcerptChars` ✓ (used)
- `Chat.NoEvidenceMessage` ✓ (used)
- `Chat.SystemPromptTemplate` → **implement** (optional override)
- `Chat.NoEvidenceAssistantContent` → **implement** (for citation tracking)

### 7.2 Update docs/project-status.md

Document Flow 2 backend completion status.

---

## Implementation Order & Dependencies

```
Phase 1 (Schema)     ──────────────────┐
    │                                        │
Phase 2 (Retrieval) ◄──────────────────────┤  (All phases need SubjectId)
    │                                        │
Phase 3 (History)  ◄────────────────────────┤
    │                                        │
Phase 4 (Resilience)                         │
    │                                        │
Phase 5 (Index)     ────────────────────────┘  (Independent, can run in parallel)
    │
Phase 6 (Tests)     ◄───────────────────────── (After all implementation)
    │
Phase 7 (Config)    ◄───────────────────────── (Verify throughout)
```

---

## File Change Summary

### New Files
1. `src/PRN222.RagAssistant/Data/Migrations/[timestamp]_AddSubjectIdToChatSession.cs`
2. `src/PRN222.RagAssistant/Data/Migrations/[timestamp]_AddHnswIndexOnDocumentChunksEmbedding.cs`
3. `tests/PRN222.RagAssistant.Tests/RagArchitectureTests.cs`
4. `tests/PRN222.RagAssistant.Tests/PgVectorDocumentChunkRetrieverTests.cs`

### Modified Files
1. `src/PRN222.RagAssistant/Domain/Entities/ChatSession.cs` — add `SubjectId`
2. `src/PRN222.RagAssistant/Data/Configurations/ChatSessionConfiguration.cs` — FK + index
3. `src/PRN222.RagAssistant/Infrastructure/Rag/InternalTypes.cs` — add `subjectId` to `IDocumentChunkRetriever`
4. `src/PRN222.RagAssistant/Infrastructure/Rag/PgVectorDocumentChunkRetriever.cs` — subject-scoped query
5. `src/PRN222.RagAssistant/Features/Rag/RagQueryService.cs` — pass SubjectId, history, resilience
6. `src/PRN222.RagAssistant/Infrastructure/Rag/GroundedPromptBuilder.cs` — history integration
7. `src/PRN222.RagAssistant/Infrastructure/ServiceCollectionExtensions.cs` — verify DI registration
8. `tests/PRN222.RagAssistant.Tests/RagQueryServiceTests.cs` — complete test coverage

---

## Acceptance Criteria

| # | Criterion | Verification |
|---|-----------|--------------|
| 1 | Subject-scoped retrieval works | Query only returns chunks from session's SubjectId |
| 2 | Session validation prevents cross-user access | Unit test: different user → ChatSessionNotFoundException |
| 3 | No-evidence path returns configured message | Unit test: empty retriever → `NoEvidenceMessage` |
| 4 | Citations have correct Rank 1..N | Unit test |
| 5 | Excerpt truncated to `ExcerptChars` | Unit test |
| 6 | Conversation history injected when enabled | Unit test with `IncludeConversationHistory = true` |
| 7 | Conversation history excluded when disabled | Unit test with `IncludeConversationHistory = false` |
| 8 | Cancellation respected during embedding/chat | Unit test with cancelled token |
| 9 | Transaction atomicity: no orphan assistant message | Unit test: chat failure → rollback |
| 10 | HNSW index created on Embedding | Migration runs, index visible in pgAdmin |
| 11 | All config options functional | Manual verification + unit tests |
| 12 | Architecture tests pass | Convention tests in test project |
| 13 | Build & all tests pass | `dotnet build && dotnet test` |

---

## Risks & Mitigations

| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| ChatSession.SubjectId migration conflicts with existing data | Low | High | Use default PRN222 SubjectId for existing sessions; coordinate with Member 1 |
| pgvector HNSW index requires pgvector 0.5.0+ | Low | Medium | Verify version in `PRN222.RagAssistant.csproj` (currently 0.3.2) — may need upgrade |
| Ollama timeout during chat generation | Medium | Medium | Set separate timeouts for embedding (30s) vs chat (5min); log clearly |
| Embedding dimension mismatch after model change | Low | Critical | `EmbeddingServiceGuard` validates; document re-index requirement clearly |
| Conversation history token overflow | Medium | Low | `MaxContextChars` limits total; truncate history if needed |

---

## Coordination Points

| Item | Coordinate With | Timing |
|------|-----------------|--------|
| ChatSession.SubjectId migration | Member 1 (Core/Data) | **Before Phase 2** |
| HNSW index migration | Member 1 | Phase 5 (can be parallel) |
| Embedding model/dimension changes | Member 1 (Provider config) + Member 3 (Indexing) | Ongoing |
| UI integration (Member 5) | Member 5 | After Phase 3 (interface stable) |
| Evaluation tooling | Member 5 | After Phase 6 |

---

## Estimated Effort

| Phase | Estimate | Notes |
|-------|----------|-------|
| Phase 1: Schema | 2-3 hours | Migration + entity config |
| Phase 2: Retrieval | 3-4 hours | Core fix + integration |
| Phase 3: History | 2-3 hours | Prompt builder + service |
| Phase 4: Resilience | 3-4 hours | Retry, cancellation, logging |
| Phase 5: Index | 1-2 hours | Migration only |
| Phase 6: Tests | 4-6 hours | Comprehensive coverage |
| Phase 7: Config/Docs | 1-2 hours | Verification + docs |
| **Total** | **16-24 hours** | ~3-4 days |

---

## Next Steps

1. **Get approval** on this plan (especially Phase 1 schema change requiring Member 1 coordination)
2. **Create migration** for ChatSession.SubjectId with Member 1
3. **Start implementation** from Phase 2 (can begin while waiting for migration approval)
4. **Daily sync** with Member 1 on schema changes, Member 5 on interface stability